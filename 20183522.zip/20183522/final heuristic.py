import random

import time

start_time = time.time()
count=0
maxResul=0
xBest=[]
xLocal=[]

# doc du lieu
i=5
input_path='input/'+str(i)
result_path='./output heuristic/20183522-'+str(i)+'-out'

f = open(input_path+'.txt', 'r')


[n, m] = [int(float(x)) for x in f.readline().split()]

d = [float(x) for x in f.readline().split()]

t = [float(x) for x in f.readline().split()]

D = [[0 for i in range(m)] for j in range(n)]
for i in range(n):
	tmp = [int(float(x)) for x in f.readline().split()]
	if(tmp[0]==0):
		continue
	else:
		for j in range(tmp[0]):
			D[i][tmp[j+1]]=1

c=[[] for i in range(n)]
for i in range(n):
    c[i]=[int(x) for x in f.readline().split()]

x = [-1 for i in range(n)]
# print(x)

sotiet = [int(x) for x in t]
for gv in range(m):
	for i in range(n):
		if(D[i][gv]==1 and x[i]<0 and (sotiet[gv]-d[i])>=0):
			sotiet[gv]-=d[i]
			x[i]=gv

# xuat ra file
def output(path, result, obj):
    with open(path+'.txt', 'w') as f:
        for class_index, teacher in enumerate(result):
            line = str(class_index) + " " + str(teacher) + "\n"
            f.write(line)
        f.write(str(int(obj)))

# tinh toan conflic
def conflic(x):
	sumConflic=0
	conflicArr=[0 for i in range(n)]

	for i in range(n):
		for j in range(i+1, n):
			if( c[i][j]==1 and x[i]==x[j] and x[i]>=0 ):
				sumConflic+=1
				conflicArr[i]+=1
				conflicArr[j]+=1
	return sumConflic, conflicArr

# giam conflic
def desConflic():
	sumConflic, conflicArr=conflic(x)
	if sumConflic==0:
		return
	indexMax = 0
	candidate=[]
	for i in range(n):
		maxConflic = max(conflicArr)
		if(conflicArr[i]==maxConflic):
			candidate.append(i)
	indexMax=random.choices(candidate)[0]

	sotiet[x[indexMax]]+=d[indexMax]
	x[indexMax] = -1

# lay ket qua
def getResult1(x):
	obj=0
	for i in range(n):
		if(x[i]>=0):
			obj+=1
	return obj

# xu ly de conflic giam toi 0
def goto0conflic(xLocal):
	print('Qua 9.89s, dung thuat toan va cap nhat ket qua')
	while (True):
		now_time = time.time()
		# print('time-'+str(now_time-start_time))
		xLocal=[int(i) for i in x]
		sumConflic, conflicArr=conflic(xLocal)
		if sumConflic>0:
			desConflic()
		else:
			xBest=xLocal
			resultBest=getResult1(xLocal)
			for i in range(n):
				print(i,' ',xBest[i])
			print(resultBest)

			output(result_path,xLocal,resultBest)
			exit()

# kiem tra khi gan x[j]=gv co gay ra conflic khong
def isConflic(gv,i):
	for j in range(n):
		if c[i][j]==1 and x[j]==gv:
			return 1
	return 0

def incValue(x):
	now_time = time.time()
	if now_time-start_time>9.89:
		goto0conflic(xLocal)
	sumConflic, conflicArr=conflic(x)
	for gv in range(m):
		if(sotiet[gv]>0):
			for i in range(n):
				i=n-1-i
				if x[i]<0 and (sotiet[gv]-d[i])>=0 and conflicArr[i]==0 and D[i][gv]==1 and isConflic(gv,i)==0:
					# print('cai thien ket qua')
					sotiet[gv]-=d[i]
					x[i]=gv
					return

# tinh toan delta conflic khi gan x[i]=gv
def getDelta(gv,i):
	x_tmp=[int(tmp) for tmp in x]
	preSumConflic, conflicArr=conflic(x_tmp)

	x_tmp[i]=gv
	nowSumConflic, conflicArr=conflic(x_tmp)
	# print('delta =', preSumConflic,'--',nowSumConflic)
	return preSumConflic-nowSumConflic

# tinh toan ket qua
def getResult():
	obj=0
	for i in range(n):
		if(x[i]>=0):
			obj+=1
	return obj

# xoa ngau nhien 1 lop roi them 1 giao vien
def randChange1():
	candidateX=[]
	for i in range(n):
		if(x[i]>=0):
			candidateX.append(i)
	indexX=random.choices(candidateX)[0]
	sotiet[x[indexX]]+=d[indexX]
	x[indexX]=-1

	candidateGV=[]
	candidatesotiet=[]
	for gv in range(m):
		if(D[indexX][gv]==1 and sotiet[gv]-d[indexX]>=0):
			candidateGV.append(gv)
			candidatesotiet.append(sotiet[gv])
	randGV=random.choices(candidateGV)[0]
	x[indexX]=randGV
	sotiet[randGV]-=d[indexX]

# xoa ngau nhien 2 lop roi them lan luot 2 giao vien
def randChange2():
	candidateX=[]
	for i in range(n):
		if(x[i]>=0):
			candidateX.append(i)
	indexList=random.sample(set(candidateX), 2)
	indexX1=indexList[0]
	indexX2=indexList[1]
	sotiet[x[indexX1]]
	d[indexX1]
	sotiet[x[indexX1]]+=d[indexX1]
	x[indexX1]=-1

	sotiet[x[indexX2]]+=d[indexX2]
	x[indexX2]=-1


	candidateGV=[]
	candidatesotiet=[]
	for gv in range(m):
		if(D[indexX1][gv]==1 and sotiet[gv]-d[indexX1]>=0):
			candidateGV.append(gv)
			candidatesotiet.append(sotiet[gv])
	randGV=random.choices(candidateGV)[0]
	x[indexX1]=randGV
	sotiet[randGV]-=d[indexX1]

	candidateGV=[]
	candidatesotiet=[]
	for gv in range(m):
		if(D[indexX2][gv]==1 and sotiet[gv]-d[indexX2]>=0):
			candidateGV.append(gv)
			candidatesotiet.append(sotiet[gv])
	if(len(candidateGV)>0):
		# print('xoa 2 roi them 2')
		randGV=random.choices(candidateGV)[0]
		x[indexX2]=randGV
		sotiet[randGV]-=d[indexX2]
	else:
		pass

# xoa ngau nhien 2 lop roi them giao vien theo thu tu nguoc lai
def randChange3():
	candidateX=[]
	for i in range(n):
		if(x[i]>=0):
			candidateX.append(i)
	indexList=random.sample(set(candidateX), 2)
	indexX1=indexList[0]
	indexX2=indexList[1]
	sotiet[x[indexX1]]
	d[indexX1]
	sotiet[x[indexX1]]+=d[indexX1]
	x[indexX1]=-1

	sotiet[x[indexX2]]+=d[indexX2]
	x[indexX2]=-1


	candidateGV=[]
	candidatesotiet=[]
	for gv in range(m):
		if(D[indexX2][gv]==1 and sotiet[gv]-d[indexX2]>=0):
			candidateGV.append(gv)
			candidatesotiet.append(sotiet[gv])
	randGV=random.choices(candidateGV)[0]
	x[indexX2]=randGV
	sotiet[randGV]-=d[indexX2]

	candidateGV=[]
	candidatesotiet=[]
	for gv in range(m):
		if(D[indexX1][gv]==1 and sotiet[gv]-d[indexX1]>=0):
			candidateGV.append(gv)
			candidatesotiet.append(sotiet[gv])
	if(len(candidateGV)>0):
		# print('xoa 2 roi them 2')
		randGV=random.choices(candidateGV)[0]
		x[indexX1]=randGV
		sotiet[randGV]-=d[indexX1]
	else:
		pass

# xoa ngau nhien 1 lop
def randomRemove():
	candidateX=[]
	for i in range(n):
		if(x[i]>=0):
			candidateX.append(i)
	indexX=random.choices(candidateX)[0]
	sotiet[x[indexX]]+=d[indexX]
	x[indexX]=-1

# cap nhat ket qua toi uu
def upDateBest():
	global maxResul,xBest
	localResult=getResult()
	if localResult>maxResul:
		maxResul=localResult
		xBest=[int(i) for i in x]

# ---------------------Search------------------------#

# for i in range(int(n/10)):
# 	desConflic()

for i in range(30):

	# giam conflic
	for i in range(7):
		desConflic()
	# tang value
	for i in range(7):
		incValue(x)


	sumConflic, conflicArr=conflic(x)
	# print(sumConflic)

	if sumConflic==0:
		# cap nhat ket qua
		upDateBest()
		count+=1
	else:
		count=0
	if count>=3:
		# conflic=0 qua 3 lan
		# print("------change random---------")
		for i in range(int(n/10)):
			rann = random.randint(0, 200)
			if rann<100:
				randChange1()
			else:
				randChange3()
		count=0


#-----------------End search------------------------#



#-----------Output----------------------------#
if(len(xBest)==0):
	print('it vong lap')
	exit()
for i in range(n):
	print(i,' ',xBest[i])		
print(maxResul)
output(result_path,xBest,maxResul)
#---------End output--------------------------#




# #--------------Check--------------------------#
# for i in range(n):
# 	for j in range(n):
# 		if c[i][j]==1 and xBest[i]==xBest[j] and i!=j and xBest[i]>0:
# 			print('thuat toan loi rang buoc conflic <=> c')

# for i in range(n):
# 	if(D[i][xBest[i]]!=1 and xBest[i]>0):
# 		print('thuat toan loi rang buoc gv m co the day lop n <=> D ', i)
# #-----------End Check--------------------------#


end_time = time.time()
elapsed_time = end_time - start_time
print ("time:{0}".format(elapsed_time) + "[sec]")



