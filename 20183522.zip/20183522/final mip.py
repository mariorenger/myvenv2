from ortools.linear_solver import pywraplp
import time

start_time = time.time()

i=5
# doc du lieu
input_path='input/'+str(i)
result_path='20183522-'+str(i)+'-out'

f = open(input_path+'.txt', 'r')

[n, m] = [int(float(x)) for x in f.readline().split()]

d = [float(x) for x in f.readline().split()]

t = [float(x) for x in f.readline().split()]

D = [[0 for i in range(m)] for j in range(n)]
for i in range(n):
	tmp = [int(float(x)) for x in f.readline().split()]
	if(tmp[0]==0):
		continue
	else:
		for j in range(tmp[0]):
			D[i][tmp[j+1]]=1

c=[[] for i in range(n)]
for i in range(n):
    c[i]=[int(x) for x in f.readline().split()]


# tao bien
solver = pywraplp.Solver.CreateSolver('CBC')
x = {}
for i in range(m):
    for j in range(n):
        x[i, j] = solver.IntVar(0, 1, 'x(' + str(i) + ',' + str(j) +')')

INF = solver.infinity()
# rang buoc moi lop chi 1 giao vien day
for i in range(n):
	cstr = solver.Constraint(0, 1)
	for gv in range(m):
		cstr.SetCoefficient(x[gv, i], 1) 

# rang buoc conflic 2 lop
for i in range(n):
	for j in range(i+1, n):
		if c[i][j]==1:
			for gv in range(m):
				if(D[i][gv]==1 and D[j][gv]==1):
					cstr = solver.Constraint(0, 1)
					cstr.SetCoefficient(x[gv, i], 1) 
					cstr.SetCoefficient(x[gv, j], 1) 

# rang buoc thoi luong cua moi giao vien
for gv in range(m):
	cstr = solver.Constraint(0, t[gv])
	for i in range(n):
		cstr.SetCoefficient(x[gv, i], d[i]) 

# rang buoc giao vien m co the day lop n: <=> D(i)
for i in range(n):
	for gv in range(m):
		if(D[i][gv]==0):
			cstr = solver.Constraint(0, 0)
			cstr.SetCoefficient(x[gv, i], 1) 

obj = solver.Objective()
for i in range(m):
    for j in range(n):
        obj.SetCoefficient(x[i, j], 1)
        
obj.SetMaximization()

result_status = solver.Solve()

assert result_status == pywraplp.Solver.OPTIMAL
# in ran man hinh ket qua
for i in range(n):
	for gv in range(m):
		if x[gv, i].solution_value() > 0:
			print(i,' ',gv)
			break
		if gv==m-1 and x[m-1, i].solution_value() == 0:
			print(i, '-1')
print(solver.Objective().Value())

# xuat ra file
def output(path, result, obj):
    with open(path+'.txt', 'w') as f:
        for class_index, teacher in enumerate(result):
            line = str(class_index) + " " + str(teacher) + "\n"
            f.write(line)
        f.write(str(int(obj)))

res = [-1 for i in range(n)]
for i in range(n):
    for gv in range(m):
        if x[gv, i].solution_value() > 0:
            res[i] = gv
output(result_path,res,solver.Objective().Value())


# #--------------check result---------------------------------#
# for i in range(n):
# 	for j in range(n):
# 		if(c[i][j]==1 and i!=j):
# 			for gv in range(m):
# 				if x[gv, i].solution_value() > 0:
# 					if x[gv, j].solution_value() > 0:
# 						print('loi giai sai conflic voi',i,'-',j)

# for gv in range(m):
# 	tmp=0
# 	for i in range(n):
# 		if x[gv, i].solution_value() > 0:
# 			tmp+=d[i]
# 	print('gv',gv,'day tat ca',tmp,'tiet tren tong',t[gv],'tiet')
# #--------------end check--------------------------------------#


end_time = time.time()
elapsed_time = end_time - start_time
print ("elapsed_time:{0}".format(elapsed_time) + "[sec]")


