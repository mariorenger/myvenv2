package com.atlassian.jira.rest.client.api;

public interface Callback {
    void execute();
}
