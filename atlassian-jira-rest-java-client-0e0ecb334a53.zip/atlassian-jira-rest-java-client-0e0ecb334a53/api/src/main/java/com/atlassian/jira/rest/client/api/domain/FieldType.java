package com.atlassian.jira.rest.client.api.domain;

/**
 * JIRA field type.
 */
public enum FieldType {
    JIRA, CUSTOM
}
