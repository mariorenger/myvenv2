JIRA REST Java Client - Application Stub
========================================

You can run the application stub with the following command:

```bash
java -jar target/jira-rest-java-client-app-<VERSIOn>-jar-with-dependencies.jar -h <HOST> -u <USERNAME> -p <PASSWORD>
```
