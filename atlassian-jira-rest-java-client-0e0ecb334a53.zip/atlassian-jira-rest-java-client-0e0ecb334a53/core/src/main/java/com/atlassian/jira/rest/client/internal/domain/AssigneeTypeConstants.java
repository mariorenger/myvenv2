package com.atlassian.jira.rest.client.internal.domain;

public class AssigneeTypeConstants {
    public static final String PROJECT_DEFAULT = "PROJECT_DEFAULT";
    public static final String COMPONENT_LEAD = "COMPONENT_LEAD";
    public static final String PROJECT_LEAD = "PROJECT_LEAD";
    public static final String UNASSIGNED = "UNASSIGNED";
}
