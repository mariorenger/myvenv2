package com.atlassian.jira.rest.client.internal.json;

import org.codehaus.jettison.json.JSONObject;

public interface JsonObjectParser<T> extends JsonParser<JSONObject, T> {
}
